const NotFound = () => {
  return (
    <section>
      <h1>404 - Page Not Found</h1>
      <p>Sorry, we couldn’t find that page.</p>
    </section>
  )
}

export default NotFound
